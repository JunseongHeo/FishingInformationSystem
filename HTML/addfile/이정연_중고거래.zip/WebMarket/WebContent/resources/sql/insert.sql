insert into product values("P1234", "Galaxy S20", 1200000,"5.25-inch, 1334*750 HD display, 16-megapixel Camera",
                         "SAMSUNG","Smart Phone",1000,"New","P1234.jpg");
insert into product values("P1235", "LG GRAM", 2000000,"13.3-inch, IPS FULL HD display, Intel Core Processor",
                         "LG","Notebook",1000,"Refurbished","P1235.jpg");
insert into product values("P1236", "Galaxy Tab", 900000,"212.8*125.6*6.6mm, Super AMOLED display, Octa-Core Processor",
                      	 "SAMSUNG","Notebook",1000,"Old","P1236.jpg");